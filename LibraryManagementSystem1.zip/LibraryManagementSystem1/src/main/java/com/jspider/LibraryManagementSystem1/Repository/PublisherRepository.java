package com.jspider.LibraryManagementSystem1.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jspider.LibraryManagementSystem1.Entity.Publisher;

public interface PublisherRepository extends JpaRepository<Publisher, Integer> {

}