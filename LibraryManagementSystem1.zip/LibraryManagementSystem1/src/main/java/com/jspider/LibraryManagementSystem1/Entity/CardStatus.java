package com.jspider.LibraryManagementSystem1.Entity;


public enum CardStatus {
	ACTIVATED,
	
	EXPIRED,
	
	DEACTIVATED
}