package com.jspider.LibraryManagementSystem1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryManagementSystem1Application {

	public static void main(String[] args) {
		SpringApplication.run(LibraryManagementSystem1Application.class, args);
	}

}