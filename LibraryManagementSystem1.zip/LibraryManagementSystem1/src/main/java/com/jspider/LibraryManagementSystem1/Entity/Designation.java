package com.jspider.LibraryManagementSystem1.Entity;


public enum Designation {
	
	STUDENT,
	
	EMPLOYEE,
	
	GRADUATED
}